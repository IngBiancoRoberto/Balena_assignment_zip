# Balena_Assignment
Notebooks and data from the Balena assignment

This repo contains all notebooks and data used for the Balena assignment.

The notebooks are named with a progressive number in a logical order. Simply follow the numbers to have the complete story.

Topics:
EDA - notebook 01
Data cleaning - nb 02 to 04
Task 1 - nb 05 and 06
Task 2 - nb 07
Task 3 - nb 08 to 10

All tasks start from the initial files servers.csv and connectivity_events.csv. This last file is not present in the repo because of size limitations.

During the Data cleaning phase other connectivity files are generated. These are not included in the repo again because of size limitations, however they can be recreated by running the notebooks. 

The only file included is connectivity_events_clean_File.csv, which is split in different files and zipped.

There is also a file aux_balena.py that contains some basic functions used across the notebooks.



