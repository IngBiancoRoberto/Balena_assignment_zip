import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from time import time

def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    start_mem = df.memory_usage().sum() / 1024**2    
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)  
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)    
    end_mem = df.memory_usage().sum() / 1024**2
    if verbose: print('Mem. usage decreased to {:5.2f} Mb ({:.1f}% reduction)'.format(end_mem, 100 * (start_mem - end_mem) / start_mem))
    return df
	
def mem_usage(df):
    return df.memory_usage().sum()/1024**2

def convert_timestamp(df, fields_to_convert):
	# converts from string to datetime
	if type(fields_to_convert) == str:
		fields_to_convert=[fields_to_convert]
	for field in fields_to_convert:
		print('Converting to timestamp field: ', field)
		df[field] = pd.to_datetime(df[field],format='%Y-%m-%d %H:%M:%S')
	return df

def read_log(log_file):
	t0 = time()
	dflog = pd.read_csv(log_file)
	dflog = reduce_mem_usage(dflog)
	print('Log read in {:.1f} s'.format(time()-t0))
	dflog = convert_timestamp(dflog, 'timestamp')
	print('Done!')
	return dflog

def read_base_log():
	log_file = 'connectivity_events.csv'
	t0 = time()
	dflog = pd.read_csv(log_file,
                    header=None, names = ['timestamp','device_id','user_id','server_id','connected'])
	dflog = reduce_mem_usage(dflog)
	print('Log read in {:.1f} s'.format(time()-t0))
	dflog = convert_timestamp(dflog, 'timestamp')
	print('Done!')
	return dflog
	
def read_server(*argv):
	if len(argv)==0:
		server_file = 'servers.csv'
	else:
		server_file = argv[0]
	dfserver= pd.read_csv(server_file,header=None, names=['server_id','created_at','destroyed_at'],index_col='server_id')
	dfserver = convert_timestamp(dfserver,['created_at','destroyed_at'])
	print('Done!')
	return dfserver
	
def null_data_stats(df):
    # statistics on null values in a dataframe
    null_data = df.isnull().sum().sort_values(ascending=False).to_frame()
    null_data.columns = ['total']
    null_data['percentage'] = null_data['total']/len(df)*100
    return null_data
	
def nunique(x):
    return len(np.unique(x))